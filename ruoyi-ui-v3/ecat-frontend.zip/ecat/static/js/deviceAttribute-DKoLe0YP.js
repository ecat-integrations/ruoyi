import{a2 as r}from"./index-Bp4u6Nsk.js";function m(t,e){return r({url:"/nowdata/attribute/scheme",method:"get",params:{deviceId:t,attributeId:e}})}export{m as g};
